package com.Tbessi.gestiondestock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
